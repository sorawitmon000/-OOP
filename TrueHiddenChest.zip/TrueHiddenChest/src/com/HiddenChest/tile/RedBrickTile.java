package com.HiddenChest.tile;

import com.HiddenChest.graphic.Assets;

public class RedBrickTile extends Tile {
    public RedBrickTile(int id) {
        super(Assets.redbrick, id);
    }
}
