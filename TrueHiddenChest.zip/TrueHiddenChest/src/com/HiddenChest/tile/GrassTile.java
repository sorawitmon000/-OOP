package com.HiddenChest.tile;

import com.HiddenChest.graphic.Assets;

import java.awt.image.BufferedImage;

public class GrassTile extends Tile{
    public GrassTile(int id) {
        super(Assets.glass, id);
    }
}
