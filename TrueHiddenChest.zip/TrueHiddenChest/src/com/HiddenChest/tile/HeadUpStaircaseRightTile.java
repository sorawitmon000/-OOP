package com.HiddenChest.tile;

import com.HiddenChest.graphic.Assets;

public class HeadUpStaircaseRightTile extends Tile {
    public HeadUpStaircaseRightTile(int id) {
        super(Assets.headupstaircaseRight, id);
    }

}
