package com.HiddenChest.tile;

import com.HiddenChest.graphic.Assets;

public class SandTile extends Tile {
    public SandTile(int id) {
        super(Assets.sand, id);
    }
}
