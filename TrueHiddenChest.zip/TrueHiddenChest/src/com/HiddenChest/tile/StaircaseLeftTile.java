package com.HiddenChest.tile;

import com.HiddenChest.graphic.Assets;

public class StaircaseLeftTile extends Tile {
    public StaircaseLeftTile(int id) {
        super(Assets.staircaseLeft, id);
    }
}
