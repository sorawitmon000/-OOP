package com.HiddenChest.tile;

import com.HiddenChest.graphic.Assets;

public class WoodPlateTile extends Tile {
    public WoodPlateTile(int id) {
        super(Assets.woodplate, id);
    }
}
