package com.HiddenChest.tile;

import com.HiddenChest.graphic.Assets;

public class UpStaircaseRightTile extends Tile {
    public UpStaircaseRightTile(int id) {
        super(Assets.upstaircaseRight, id);
    }
}
