package com.HiddenChest.tile;

import com.HiddenChest.graphic.Assets;

public class StaircaseRightTile extends Tile {
    public StaircaseRightTile(int id) {
        super(Assets.staircaseRight, id);
    }
}
