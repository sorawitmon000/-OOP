package com.HiddenChest.tile;

import com.HiddenChest.graphic.Assets;

public class HeadUpStaircaseLeftTile extends Tile {
    public HeadUpStaircaseLeftTile(int id) {
        super(Assets.headupstaircaseLeft, id);
    }

}
