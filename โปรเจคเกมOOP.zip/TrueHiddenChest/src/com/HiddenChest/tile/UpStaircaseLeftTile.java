package com.HiddenChest.tile;

import com.HiddenChest.graphic.Assets;

public class UpStaircaseLeftTile extends Tile {
    public UpStaircaseLeftTile(int id) {
        super(Assets.upstaircaseLeft, id);
    }
}
