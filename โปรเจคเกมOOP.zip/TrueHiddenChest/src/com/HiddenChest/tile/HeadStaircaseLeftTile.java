package com.HiddenChest.tile;

import com.HiddenChest.graphic.Assets;

public class HeadStaircaseLeftTile  extends Tile {
    public HeadStaircaseLeftTile(int id) {
        super(Assets.headstaircaseLeft, id);
    }

}
