package com.HiddenChest.tile;

import com.HiddenChest.graphic.Assets;

public class WoodWaterTile extends Tile {
    public WoodWaterTile(int id) {
        super(Assets.woodwater, id);
    }
}
