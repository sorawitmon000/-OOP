package com.HiddenChest.tile;

import com.HiddenChest.graphic.Assets;

public class BlueBrickTile extends Tile{
    public BlueBrickTile(int id) {
        super(Assets.bluebrick, id);
    }
}
