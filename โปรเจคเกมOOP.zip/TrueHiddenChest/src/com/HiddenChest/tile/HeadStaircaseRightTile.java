package com.HiddenChest.tile;

import com.HiddenChest.graphic.Assets;

public class HeadStaircaseRightTile extends Tile{
    public HeadStaircaseRightTile(int id) {
        super(Assets.headstaircaseRight, id);
    }

}
