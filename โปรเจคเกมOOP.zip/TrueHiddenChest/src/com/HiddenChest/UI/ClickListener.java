package com.HiddenChest.UI;
/*
       อินเตอเฟสเมธอดเวลากดปุ่ม
 */
public interface ClickListener {
    public void onClick();
}
